package com.classselector;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Árvore de habilidades em painel escuro (desenhado por código, sem texturas):
 * lista de árvores à esquerda, árvore no centro (de cima para baixo) e detalhes à direita.
 */
public class SkillScreen extends Screen {
    private static final int NODE = 26, GX = 44, GY = 42;

    // paleta
    private static final int C_PANEL = 0xFF1A2028, C_BORDER = 0xFF3C4654, C_IN = 0xFF39434F;
    private static final int C_INNER = 0xFF12171D, C_BAR = 0xFF222A34;
    private static final int C_TEXT = 0xFFE6EAF0, C_SUB = 0xFF8B97A6, C_BODY = 0xFFB8C2CF;
    private static final int C_GOLD = 0xFFFFD27A, C_GREEN = 0xFF7BE07B, C_RED = 0xFFFF6B6B;
    private static final int C_YELLOW = 0xFFFFE066, C_CYAN = 0xFF6FD0E8, C_SEL = 0xFFEFE6B8;
    private static final int C_LINE_ON = 0xFFB9C6DA, C_LINE_OFF = 0xFF4A5360;

    private static String lastTab = null;
    private static String selId = "";

    private double sx, sy, pressX, pressY;
    private boolean pressing, dragged;
    private int listOffset;
    private int baseX, baseY, nextSlot;

    // geometria (calculada em init)
    private int px, py, pw, ph, lw, rw, cy, ch, listX, areaX, areaW, rightX, bottomY;
    private int btnX, btnY, btnW;

    public SkillScreen() { super(Component.literal("Habilidades")); }

    @Override
    protected void init() {
        boolean op = ClientState.op;
        pw = Math.min(width - 12, 440);
        ph = Math.min(height - (op ? 56 : 12), 250);
        px = (width - pw) / 2;
        py = (height - ph - (op ? 26 : 0)) / 2;
        lw = Mth.clamp(pw / 5, 70, 88);
        rw = Mth.clamp(pw / 4, 96, 118);
        cy = py + 32;
        bottomY = py + ph - 26;
        ch = bottomY - 4 - cy;
        listX = px + 4;
        areaX = listX + lw + 4;
        areaW = pw - lw - rw - 16;
        rightX = areaX + areaW + 4;
        btnX = rightX + 6;
        btnW = rw - 12;
        btnY = cy + ch - 26;

        if (op) {
            int by = py + ph + 6;
            addRenderableWidget(Button.builder(Component.literal("+ Árvore"),
                    b -> minecraft.setScreen(new QuestTabEditScreen(this, null, true)))
                    .bounds(px, by, 62, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Editar árvore"), b -> {
                QuestTabDef t = currentTab();
                if (t != null) minecraft.setScreen(new QuestTabEditScreen(this, t, true));
            }).bounds(px + 66, by, 80, 20).build());
            addRenderableWidget(Button.builder(Component.literal("+ Skill"), b -> {
                QuestTabDef t = currentTab();
                if (t != null) minecraft.setScreen(new SkillEditScreen(this, t.id, null));
            }).bounds(px + 150, by, 58, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Editar skill"), b -> {
                QuestTabDef t = currentTab();
                SkillDef q = selected(t);
                if (q != null) minecraft.setScreen(new SkillEditScreen(this, t.id, q));
            }).bounds(px + 212, by, 72, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Itens da skill"), b -> {
                SkillDef q = selected(currentTab());
                if (q != null) Net.CH.sendToServer(new SkillNet.SEditRewards(q.id));
            }).bounds(px + 288, by, 78, 20).build());
        }
    }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (QuestKeys.SKILLS.matches(key, scan)) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    private QuestTabDef currentTab() {
        List<QuestTabDef> tl = SkillClientState.trees;
        if (tl.isEmpty()) return null;
        for (QuestTabDef t : tl) if (t.id.equals(lastTab)) return t;
        lastTab = tl.get(0).id;
        return tl.get(0);
    }

    private SkillDef selected(QuestTabDef tab) {
        if (tab == null || selId.isEmpty()) return null;
        SkillDef s = SkillClientState.skills.get(selId);
        return s != null && s.tree.equals(tab.id) ? s : null;
    }

    private String className(String cid) {
        for (ClassDef c : ClientState.classes) if (c.id.equals(cid)) return c.name;
        return cid;
    }

    private boolean canUnlock(SkillDef q) {
        if (SkillClientState.unlocked.contains(q.id) || !SkillClientState.available(q)) return false;
        return minecraft.player.getAbilities().instabuild || minecraft.player.experienceLevel >= q.xpCost;
    }

    // ---------- layout da árvore (de cima para baixo) ----------
    private double assign(SkillDef q, int depth, Map<String, List<SkillDef>> kids,
                          Map<String, double[]> pos, Set<String> seen) {
        seen.add(q.id);
        List<SkillDef> ch2 = new ArrayList<>();
        for (SkillDef c : kids.getOrDefault(q.id, List.of())) if (!seen.contains(c.id)) ch2.add(c);
        double x;
        if (ch2.isEmpty()) {
            x = nextSlot++;
        } else {
            double first = 0, last = 0;
            boolean f = true;
            for (SkillDef c : ch2) {
                double cx = assign(c, depth + 1, kids, pos, seen);
                if (f) { first = cx; f = false; }
                last = cx;
            }
            x = (first + last) / 2.0;
        }
        pos.put(q.id, new double[]{x, depth});
        return x;
    }

    private Map<String, double[]> layout(String tree) {
        List<SkillDef> list = new ArrayList<>();
        Set<String> ids = new HashSet<>();
        for (SkillDef q : SkillClientState.skills.values()) {
            if (q.tree.equals(tree)) { list.add(q); ids.add(q.id); }
        }
        Map<String, List<SkillDef>> kids = new HashMap<>();
        List<SkillDef> roots = new ArrayList<>();
        for (SkillDef q : list) {
            if (q.parent.isEmpty() || !ids.contains(q.parent) || q.parent.equals(q.id)) roots.add(q);
            else kids.computeIfAbsent(q.parent, k -> new ArrayList<>()).add(q);
        }
        Map<String, double[]> pos = new LinkedHashMap<>();
        Set<String> seen = new HashSet<>();
        nextSlot = 0;
        for (SkillDef r : roots) assign(r, 0, kids, pos, seen);
        for (SkillDef q : list) if (!pos.containsKey(q.id) && !seen.contains(q.id)) assign(q, 0, kids, pos, seen);
        return pos;
    }

    private void clampPan(Map<String, double[]> pos) {
        double mxX = 0, mxY = 0;
        for (double[] p : pos.values()) { mxX = Math.max(mxX, p[0]); mxY = Math.max(mxY, p[1]); }
        int treeW = (int) (mxX * GX) + NODE, treeH = (int) (mxY * GY) + NODE;
        int cw = treeW + 24, chh = treeH + 28;
        if (cw <= areaW) { baseX = (areaW - treeW) / 2; sx = 0; }
        else { baseX = 12; sx = Mth.clamp(sx, areaW - cw, 0); }
        if (chh <= ch) { baseY = 14; sy = 0; }
        else { baseY = 14; sy = Mth.clamp(sy, ch - chh, 0); }
    }

    private int nodeX(double slot) { return areaX + baseX + (int) (slot * GX) + (int) sx; }
    private int nodeY(double depth) { return cy + baseY + (int) (depth * GY) + (int) sy; }

    private boolean inArea(double mx, double my) {
        return mx >= areaX + 2 && mx < areaX + areaW - 2 && my >= cy + 2 && my < cy + ch - 2;
    }

    private SkillDef hitSkill(double mx, double my) {
        QuestTabDef tab = currentTab();
        if (tab == null || !inArea(mx, my)) return null;
        Map<String, double[]> pos = layout(tab.id);
        clampPan(pos);
        for (Map.Entry<String, double[]> e : pos.entrySet()) {
            int nx = nodeX(e.getValue()[0]), ny = nodeY(e.getValue()[1]);
            if (mx >= nx && mx < nx + NODE && my >= ny && my < ny + NODE) return SkillClientState.skills.get(e.getKey());
        }
        return null;
    }

    // ---------- desenho ----------
    private static void box(GuiGraphics g, int x, int y, int w, int h, int border, int fill) {
        g.fill(x + 1, y, x + w - 1, y + h, border);
        g.fill(x, y + 1, x + w, y + h - 1, border);
        g.fill(x + 2, y + 1, x + w - 2, y + h - 1, fill);
        g.fill(x + 1, y + 2, x + w - 1, y + h - 2, fill);
    }

    private static void outline(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x + 1, y, x + w - 1, y + 1, c);
        g.fill(x + 1, y + h - 1, x + w - 1, y + h, c);
        g.fill(x, y + 1, x + 1, y + h - 1, c);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, c);
    }

    /** Retângulo por cima dos itens (z maior que o do ícone). */
    private static void overlay(GuiGraphics g, int x1, int y1, int x2, int y2, int color) {
        g.pose().pushPose();
        g.pose().translate(0, 0, 200);
        g.fill(x1, y1, x2, y2, color);
        g.pose().popPose();
    }

    private static void lock(GuiGraphics g, int x, int y) {
        g.pose().pushPose();
        g.pose().translate(0, 0, 250);
        int c = 0xFFD0D8E2;
        g.fill(x + 1, y, x + 6, y + 1, c);
        g.fill(x + 1, y, x + 2, y + 4, c);
        g.fill(x + 5, y, x + 6, y + 4, c);
        g.fill(x, y + 3, x + 7, y + 8, c);
        g.fill(x + 3, y + 5, x + 4, y + 7, 0xFF1C2229);
        g.pose().popPose();
    }

    /** state: 0 = bloqueada, 1 = disponível, 2 = desbloqueada. */
    private void node(GuiGraphics g, int x, int y, int state, boolean sel, SkillDef q) {
        int border = state == 2 ? 0xFF6FA0F0 : state == 1 ? 0xFFB7C0CC : 0xFF3E4752;
        int fill = state == 2 ? 0xFF2F4F86 : state == 1 ? 0xFF2A323D : 0xFF1C2229;
        if (sel) outline(g, x - 3, y - 3, NODE + 6, NODE + 6, C_SEL);
        box(g, x, y, NODE, NODE, border, fill);
        g.renderItem(q.iconStack(), x + 5, y + 5);
        if (state == 0) {
            overlay(g, x + 2, y + 2, x + NODE - 2, y + NODE - 2, 0xB0000000);
            lock(g, x + NODE / 2 - 3, y + NODE / 2 - 4);
        }
    }

    private int wrap(GuiGraphics g, String text, int x, int y, int w, int color, int maxLines) {
        List<FormattedCharSequence> ls = font.split(Component.literal(text), w);
        for (int i = 0; i < ls.size() && i < maxLines; i++) {
            g.drawString(font, ls.get(i), x, y, color, false);
            y += 10;
        }
        return y;
    }

    private int stateOf(SkillDef q) {
        if (SkillClientState.unlocked.contains(q.id)) return 2;
        return SkillClientState.available(q) ? 1 : 0;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        QuestTabDef tab = currentTab();
        Map<String, double[]> pos = tab == null ? new LinkedHashMap<>() : layout(tab.id);
        clampPan(pos);
        SkillDef sel = selected(tab);
        SkillDef hover = null;

        // moldura e título
        box(g, px, py, pw, ph, C_BORDER, C_PANEL);
        box(g, px + 4, py + 4, pw - 8, 24, C_IN, C_BAR);
        g.renderItem(new ItemStack(Items.NETHER_STAR), px + 10, py + 8);
        g.pose().pushPose();
        g.pose().translate(px + 30, py + 10, 0);
        g.pose().scale(1.3f, 1.3f, 1f);
        g.drawString(font, "Árvore de Habilidades", 0, 0, C_TEXT, false);
        g.pose().popPose();
        String sub = "Desbloqueie seu potencial.";
        if (pw > 340) g.drawString(font, sub, px + pw - 10 - font.width(sub), py + 12, C_SUB, false);

        // lista de árvores (esquerda)
        box(g, listX, cy, lw, ch, C_IN, C_INNER);
        List<QuestTabDef> tl = SkillClientState.trees;
        int rows = Math.max(1, (ch - 6) / 28);
        listOffset = Mth.clamp(listOffset, 0, Math.max(0, tl.size() - rows));
        for (int i = 0; i < rows && listOffset + i < tl.size(); i++) {
            QuestTabDef t = tl.get(listOffset + i);
            int ex = listX + 3, ey = cy + 3 + i * 28, ew = lw - 6;
            boolean on = tab != null && t.id.equals(tab.id);
            boolean hov = mx >= ex && mx < ex + ew && my >= ey && my < ey + 26;
            box(g, ex, ey, ew, 26, on ? C_SEL : hov ? 0xFF5A6677 : C_IN, on ? 0xFF2E3A4A : C_BAR);
            g.renderItem(t.iconStack(), ex + 4, ey + 5);
            int nc = on ? C_TEXT : C_BODY;
            if (t.classId.isEmpty()) {
                g.drawString(font, font.plainSubstrByWidth(t.name, ew - 28), ex + 24, ey + 9, nc, false);
            } else {
                g.drawString(font, font.plainSubstrByWidth(t.name, ew - 28), ex + 24, ey + 4, nc, false);
                g.drawString(font, font.plainSubstrByWidth(className(t.classId), ew - 28), ex + 24, ey + 14, C_CYAN, false);
            }
        }
        if (tl.isEmpty()) g.drawString(font, "Nenhuma árvore", listX + 6, cy + 8, C_SUB, false);

        // árvore (centro)
        box(g, areaX, cy, areaW, ch, C_IN, C_INNER);
        g.enableScissor(areaX + 2, cy + 2, areaX + areaW - 2, cy + ch - 2);
        int ox = Math.floorMod((int) sx, 16), oy = Math.floorMod((int) sy, 16);
        for (int gx = areaX + ox; gx < areaX + areaW; gx += 16)
            for (int gy = cy + oy; gy < cy + ch; gy += 16)
                g.fill(gx, gy, gx + 1, gy + 1, 0xFF1F262E);

        if (tab != null) {
            for (Map.Entry<String, double[]> e : pos.entrySet()) {
                SkillDef q = SkillClientState.skills.get(e.getKey());
                double[] pp = pos.get(q.parent);
                if (pp == null) continue;
                int x1 = nodeX(pp[0]) + NODE / 2, y1 = nodeY(pp[1]) + NODE;
                int x2 = nodeX(e.getValue()[0]) + NODE / 2, y2 = nodeY(e.getValue()[1]);
                int mid = y1 + (y2 - y1) / 2;
                int col = SkillClientState.unlocked.contains(q.parent) ? C_LINE_ON : C_LINE_OFF;
                g.fill(x1 - 1, y1, x1 + 1, mid + 1, col);
                g.fill(Math.min(x1, x2) - 1, mid - 1, Math.max(x1, x2) + 1, mid + 1, col);
                g.fill(x2 - 1, mid, x2 + 1, y2, col);
            }
            for (Map.Entry<String, double[]> e : pos.entrySet()) {
                SkillDef q = SkillClientState.skills.get(e.getKey());
                int nx = nodeX(e.getValue()[0]), ny = nodeY(e.getValue()[1]);
                node(g, nx, ny, stateOf(q), q.id.equals(selId), q);
                if (inArea(mx, my) && mx >= nx && mx < nx + NODE && my >= ny && my < ny + NODE) hover = q;
            }
            if (pos.isEmpty())
                g.drawCenteredString(font, "Nenhuma habilidade nesta árvore", areaX + areaW / 2, cy + ch / 2 - 4, C_SUB);
        } else {
            g.drawCenteredString(font, "Nenhuma árvore criada", areaX + areaW / 2, cy + ch / 2 - 4, C_SUB);
        }
        g.disableScissor();

        details(g, mx, my, tab, sel);

        // barra inferior: progresso e XP
        box(g, px + 4, bottomY, pw - 8, 22, C_IN, C_BAR);
        int total = 0, got = 0;
        for (SkillDef q : SkillClientState.skills.values()) {
            if (tab == null || !q.tree.equals(tab.id)) continue;
            total++;
            if (SkillClientState.unlocked.contains(q.id)) got++;
        }
        String lab = "Progresso: " + got + "/" + total;
        g.drawString(font, lab, px + 12, bottomY + 7, C_SUB, false);
        String xp = "XP: " + minecraft.player.experienceLevel + " níveis";
        int xw = font.width(xp);
        g.drawString(font, xp, px + pw - 12 - xw, bottomY + 7, 0xFF8DFF6B, false);
        int bx = px + 12 + font.width(lab) + 8;
        int bw = Math.min(150, px + pw - 12 - xw - 10 - bx);
        if (bw > 20) {
            g.fill(bx, bottomY + 8, bx + bw, bottomY + 14, C_IN);
            g.fill(bx + 1, bottomY + 9, bx + bw - 1, bottomY + 13, C_INNER);
            if (total > 0) g.fill(bx + 1, bottomY + 9, bx + 1 + (bw - 2) * got / total, bottomY + 13, 0xFF6FA0F0);
        }

        super.render(g, mx, my, pt);

        if (hover != null) {
            List<FormattedCharSequence> tip = new ArrayList<>();
            tip.add(Component.literal(hover.name).withStyle(ChatFormatting.GOLD).getVisualOrderText());
            if (hover.xpCost > 0)
                tip.add(Component.literal("Custo: " + hover.xpCost + " níveis").withStyle(ChatFormatting.GRAY).getVisualOrderText());
            g.renderTooltip(font, tip, mx, my);
        }
    }

    /** Painel da direita: detalhes da habilidade selecionada e botão de desbloquear. */
    private void details(GuiGraphics g, int mx, int my, QuestTabDef tab, SkillDef sel) {
        box(g, rightX, cy, rw, ch, C_IN, C_INNER);
        int x = rightX + 6, w = rw - 12, y = cy + 6;

        if (sel == null) {
            if (tab != null) {
                y = wrap(g, tab.name, x, y, w, C_GOLD, 2);
                if (!tab.classId.isEmpty())
                    y = wrap(g, "Exclusiva: " + className(tab.classId), x, y + 2, w, C_CYAN, 2);
            }
            wrap(g, "Clique numa habilidade para ver os detalhes.", x, y + 8, w, C_SUB, 5);
            return;
        }

        boolean done = SkillClientState.unlocked.contains(sel.id);
        boolean open = SkillClientState.available(sel);
        boolean free = minecraft.player.getAbilities().instabuild;
        boolean afford = free || minecraft.player.experienceLevel >= sel.xpCost;

        node(g, x, y, stateOf(sel), false, sel);
        wrap(g, sel.name, x + 32, y + 4, w - 32, C_GOLD, 2);
        y += 32;
        if (!sel.description.isEmpty()) y = wrap(g, sel.description, x, y, w, C_BODY, 4);
        y += 3;
        g.fill(x, y, x + w, y + 1, C_IN);
        y += 5;

        if (sel.xpCost > 0) {
            g.drawString(font, "Custo", x, y, C_SUB, false);
            String v = sel.xpCost + " níveis";
            g.drawString(font, v, x + w - font.width(v), y, done || afford ? C_GREEN : C_RED, false);
            y += 12;
        }
        if (!sel.rewards.isEmpty() || sel.xpReward > 0) {
            g.drawString(font, "Você recebe", x, y, C_SUB, false);
            y += 11;
            int limit = btnY - 14;
            for (ItemStack s : sel.rewards) {
                if (y + 16 > limit) { g.drawString(font, "...", x, y, C_SUB, false); y += 10; break; }
                g.renderItem(s, x, y);
                g.renderItemDecorations(font, s, x, y);
                g.drawString(font, font.plainSubstrByWidth(s.getHoverName().getString(), w - 22), x + 20, y + 4, C_TEXT, false);
                y += 18;
            }
            if (sel.xpReward > 0 && y + 10 <= limit + 4)
                g.drawString(font, "+" + sel.xpReward + " níveis de XP", x, y + 2, C_GREEN, false);
        }

        // estado + botão
        String st;
        int sc;
        if (done) { st = "Desbloqueada"; sc = C_GREEN; }
        else if (!open) {
            SkillDef par = SkillClientState.skills.get(sel.parent);
            st = "Requer: " + (par == null ? sel.parent : par.name);
            sc = C_RED;
        } else if (!afford) { st = "XP insuficiente"; sc = C_RED; }
        else { st = "Disponível"; sc = C_YELLOW; }
        g.drawString(font, font.plainSubstrByWidth(st, w), x, btnY - 11, sc, false);

        boolean can = canUnlock(sel);
        boolean hov = can && mx >= btnX && mx < btnX + btnW && my >= btnY && my < btnY + 20;
        box(g, btnX, btnY, btnW, 20, can ? (hov ? 0xFFE8EEF8 : 0xFFB7C0CC) : C_IN,
                can ? (hov ? 0xFF4A5C78 : 0xFF3A4A60) : C_BAR);
        g.drawCenteredString(font, done ? "Desbloqueada" : can ? "Desbloquear" : "Bloqueada",
                btnX + btnW / 2, btnY + 6, can ? 0xFFFFFFFF : 0xFF6F7B8A);
    }

    // ---------- entrada ----------
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        List<QuestTabDef> tl = SkillClientState.trees;

        // lista de árvores
        int rows = Math.max(1, (ch - 6) / 28);
        for (int i = 0; i < rows && listOffset + i < tl.size(); i++) {
            int ex = listX + 3, ey = cy + 3 + i * 28, ew = lw - 6;
            if (mx >= ex && mx < ex + ew && my >= ey && my < ey + 26) {
                QuestTabDef t = tl.get(listOffset + i);
                if (button == 0) {
                    lastTab = t.id;
                    selId = "";
                    sx = 0;
                    sy = 0;
                    return true;
                }
                if (button == 1 && ClientState.op) {
                    minecraft.setScreen(new QuestTabEditScreen(this, t, true));
                    return true;
                }
            }
        }

        QuestTabDef tab = currentTab();
        SkillDef sel = selected(tab);

        // botão "Desbloquear"
        if (button == 0 && sel != null && canUnlock(sel)
                && mx >= btnX && mx < btnX + btnW && my >= btnY && my < btnY + 20) {
            Net.CH.sendToServer(new SkillNet.SUnlock(sel.id));
            return true;
        }

        if (button == 1 && ClientState.op) {
            SkillDef q = hitSkill(mx, my);
            if (q != null && tab != null) {
                minecraft.setScreen(new SkillEditScreen(this, tab.id, q));
                return true;
            }
        }
        if (button == 0 && inArea(mx, my)) {
            pressX = mx;
            pressY = my;
            pressing = true;
            dragged = false;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (button == 0 && pressing) {
            pressing = false;
            if (!dragged) {
                SkillDef q = hitSkill(mx, my);
                if (q != null) {
                    selId = q.id; // só seleciona; desbloquear é pelo botão
                    return true;
                }
            }
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button == 0 && pressing) {
            if (Math.abs(mx - pressX) + Math.abs(my - pressY) > 4) dragged = true;
            if (dragged) {
                sx += dx;
                sy += dy;
            }
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (mx >= listX && mx < listX + lw && my >= cy && my < cy + ch) {
            listOffset -= (int) Math.signum(delta);
            return true;
        }
        return super.mouseScrolled(mx, my, delta);
    }
}
