#!/usr/bin/env python3
"""Gera o Hyper Arco de Sculk: textura 64x64 (tiles 16x16) e modelos 3D de cubos:
repouso + 4 estágios de carga (o último = carga máxima, com halo no núcleo).
Uso: python3 gen_bow.py
Frame local: arco vertical (pontas em y), disparo para +x, corda atrás (x menor). Todos os elementos
são girados 45° em Z para cair na convenção diagonal do arco vanilla (display vanilla funciona)."""
import json, os, random
from PIL import Image

ROOT = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(ROOT, "src/main/resources/assets/classselector")
NAME = "hyper_sculk_bow"
random.seed(23)
T = 16  # tamanho do tile

PAL = {
    "black": (6, 12, 20), "coal": (16, 24, 32), "navy": (24, 53, 74), "teal": (20, 80, 100),
    "sculk": (8, 124, 186), "cyan": (36, 233, 255), "ice": (112, 245, 255), "white": (230, 252, 255),
    "deep": (10, 50, 150),
}
TILES = {"dark": (0, 0), "mid": (1, 0), "glow": (2, 0), "core": (3, 0),
         "string": (0, 1), "spike": (1, 1), "vein": (2, 1), "tip": (3, 1)}

img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
def put(t, x, y, c):
    if 0 <= x < T and 0 <= y < T:
        img.putpixel((TILES[t][0] * T + x, TILES[t][1] * T + y), PAL[c] + (255,))
def get(t, x, y):
    return img.getpixel((TILES[t][0] * T + x, TILES[t][1] * T + y))

def noise_tile(t, shades, bumps=0.0, glow_dots=0):
    for y in range(T):
        for x in range(T):
            put(t, x, y, random.choice(shades))
    for _ in range(int(bumps * T * T)):               # nódulos de sculk
        x, y = random.randrange(T), random.randrange(T)
        put(t, x, y, "teal"); put(t, x + 1, y, "navy")
    for _ in range(glow_dots):
        put(t, random.randrange(T), random.randrange(T), "cyan")

def vein(t, n):
    for _ in range(n):
        x, y = random.randrange(T), random.randrange(T)
        for _ in range(random.randint(5, 10)):
            put(t, x, y, "cyan")
            if random.random() < .5: put(t, x + 1, y, "sculk")
            x += random.choice([-1, 0, 1]); y += random.choice([0, 1])
            x %= T; y %= T

noise_tile("dark", ["black", "coal", "coal", "navy"], bumps=.05, glow_dots=3)
noise_tile("mid", ["coal", "navy", "navy", "teal"], bumps=.08, glow_dots=4)
vein("mid", 2)
noise_tile("vein", ["black", "coal", "coal", "navy"]); vein("vein", 4)
for y in range(T):
    for x in range(T):
        put("glow", x, y, random.choice(["cyan", "cyan", "ice", "sculk"]))
for y in range(T):                                      # núcleo: olho de energia
    for x in range(T):
        d = (((x - 7.5) / 1.0) ** 2 + ((y - 7.5) / 1.25) ** 2) ** .5
        put("core", x, y, "white" if d < 2.2 else "ice" if d < 3.6 else "cyan" if d < 5.0 else "sculk" if d < 6.3 else "deep")
for y in range(5, 11):                                  # pupila escura (fenda)
    for x in (7, 8):
        put("core", x, y, "black")
for y in range(T):
    for x in range(T):
        put("string", x, y, "white" if x in (7, 8) else "ice" if x in (6, 9) else "cyan")
for y in range(T):
    for x in range(T):
        put("spike", x, y, random.choice(["teal", "sculk", "sculk", "cyan"]))
        put("tip", x, y, random.choice(["ice", "ice", "white", "cyan"]))
os.makedirs(os.path.join(RES, "textures/item"), exist_ok=True)
img.save(os.path.join(RES, f"textures/item/{NAME}.png"))

def uv(t):
    x, y = TILES[t]
    return [x * T, y * T, x * T + T, y * T + T]

def build(pull, halo):
    els = []
    def cube(name, a, b, tile):
        faces = {f: {"uv": uv(tile), "texture": "#0"} for f in ("north", "east", "south", "west", "up", "down")}
        els.append({"name": name, "from": a, "to": b,
                    "rotation": {"angle": 45, "axis": "z", "origin": [8, 8, 8]}, "faces": faces})
    cube("empunhadura", [8.5, 5, 6.6], [11.5, 11, 9.4], "dark")
    cube("nucleo", [8.0, 5.5, 6.0], [13.0, 10.5, 10.0], "core")
    cube("espinho_f", [13.0, 7.2, 7.2], [15.2, 8.8, 8.8], "spike")
    cube("espinho_t", [5.8, 7.2, 7.2], [8.0, 8.8, 8.8], "spike")
    cube("espinho_c", [9.6, 10.5, 7.2], [11.2, 12.4, 8.8], "spike")
    cube("espinho_b", [9.6, 3.6, 7.2], [11.2, 5.5, 8.8], "spike")
    for i, (x, y) in enumerate([(12.6, 10.0), (12.6, 4.4), (8.0, 10.0), (8.0, 4.4)]):
        cube(f"estrela{i}", [x, y, 7.0], [x + 1.4, y + 1.4, 9.0], "glow")
    if halo:  # carga máxima: halo luminoso ao redor do núcleo
        cube("halo_f", [13.0, 6.0, 6.6], [14.6, 10.0, 9.4], "tip")
        cube("halo_c", [8.5, 10.5, 6.6], [12.5, 12.0, 9.4], "tip")
        cube("halo_b", [8.5, 4.0, 6.6], [12.5, 5.5, 9.4], "tip")
        cube("halo_t", [6.4, 6.0, 6.6], [8.0, 10.0, 9.4], "tip")
    limb = [(8.8, 11.2, 11.0, 14.0, "mid"), (8.4, 10.6, 14.0, 17.0, "dark"),
            (7.8, 9.8, 17.0, 20.0, "mid"), (7.0, 9.0, 20.0, 23.0, "dark"), (6.2, 8.2, 23.0, 26.0, "mid")]
    for i, (x0, x1, y0, y1, t) in enumerate(limb):
        cube(f"membro_cima{i}", [x0, y0, 7.0], [x1, y1, 9.0], t)
        cube(f"membro_baixo{i}", [x0, 16 - y1, 7.0], [x1, 16 - y0, 9.0], t)
        if i % 2 == 0:
            cube(f"veia_cima{i}", [x0 + 0.5, y0 + .8, 8.9], [x0 + 1.5, y1 - .4, 9.4], "vein")
            cube(f"veia_baixo{i}", [x0 + 0.5, 16 - y1 + .4, 8.9], [x0 + 1.5, 16 - y0 - .8, 9.4], "vein")
    for i, (x, y) in enumerate([(10.8, 15.0), (9.0, 21.0), (10.8, 1.0), (9.0, -5.0)]):
        cube(f"cristal{i}", [x, y, 6.6], [x + 1.4, y + 1.8, 8.2], "glow")
    cube("ponta_cima", [5.4, 26.0, 7.3], [7.4, 29.0, 8.7], "tip")
    cube("ponta_baixo", [5.4, -13.0, 7.3], [7.4, -10.0, 8.7], "tip")
    cube("ponta_cima2", [5.8, 29.0, 7.6], [6.8, 30.5, 8.4], "tip")
    cube("ponta_baixo2", [5.8, -14.5, 7.6], [6.8, -13.0, 8.4], "tip")
    sx = 5.6   # corda: o centro recua com a carga
    for i, (y0, y1, f) in enumerate([(-10.0, -2.0, 0.0), (-2.0, 3.0, 0.55), (3.0, 13.0, 1.0),
                                     (13.0, 18.0, 0.55), (18.0, 26.0, 0.0)]):
        back = pull * f
        cube(f"corda{i}", [sx - back, y0, 7.75], [sx - back + 0.5, y1, 8.25], "string")
    return els

# Comprimento do modelo = 45 px; escala 0.59 => ~1,65 bloco na mão (3ª pessoa).
S3, S1, SG = 0.59, 0.45, 0.42
DISPLAY = {
    "thirdperson_righthand": {"rotation": [-80, 260, -40], "translation": [-1, -2, 2.5], "scale": [S3] * 3},
    "thirdperson_lefthand":  {"rotation": [-80, -280, 40], "translation": [-1, -2, 2.5], "scale": [S3] * 3},
    "firstperson_righthand": {"rotation": [0, -90, 25], "translation": [1.13, 3.2, 1.13], "scale": [S1] * 3},
    "firstperson_lefthand":  {"rotation": [0, 90, -25], "translation": [1.13, 3.2, 1.13], "scale": [S1] * 3},
    "gui":    {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [SG] * 3},
    "fixed":  {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [SG] * 3},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 3, 0], "scale": [0.35] * 3},
}

def model(pull, halo=False, overrides=None):
    els = build(pull, halo)
    for e in els:
        assert all(-16 <= v <= 32 for v in e["from"] + e["to"]), e["name"]
    m = {"texture_size": [64, 64],
         "textures": {"0": f"classselector:item/{NAME}", "particle": f"classselector:item/{NAME}"},
         "elements": els, "display": DISPLAY}
    if overrides:
        m["overrides"] = overrides
    return m

d = os.path.join(RES, "models/item")
os.makedirs(d, exist_ok=True)
def save(name, m):
    with open(os.path.join(d, name + ".json"), "w", encoding="utf-8") as f:
        json.dump(m, f, indent=2)

ov = [
    {"predicate": {"pulling": 1}, "model": f"classselector:item/{NAME}_pulling_0"},
    {"predicate": {"pulling": 1, "pull": 0.4}, "model": f"classselector:item/{NAME}_pulling_1"},
    {"predicate": {"pulling": 1, "pull": 0.8}, "model": f"classselector:item/{NAME}_pulling_2"},
    {"predicate": {"pulling": 1, "pull": 1.0}, "model": f"classselector:item/{NAME}_pulling_3"},
]
save(NAME, model(0.0, overrides=ov))
save(f"{NAME}_pulling_0", model(1.5))
save(f"{NAME}_pulling_1", model(3.5))
save(f"{NAME}_pulling_2", model(5.5))
save(f"{NAME}_pulling_3", model(6.5, halo=True))
print("ok")
